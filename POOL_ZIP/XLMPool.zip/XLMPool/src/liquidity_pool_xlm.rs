use core::panic;

use crate::errors::{InterestRateError, LendingError, LendingTokenError};
use crate::events::{
    LendingDepositEvent, LendingTokenBurnEvent, LendingTokenMintEvent, LendingWithdrawEvent,
};
use crate::types::{ContractDetails, DataKey, PoolDataKey, TokenDataKey};
use soroban_sdk::{
    contract, contractimpl, log, panic_with_error, token, Address, BytesN, Env, String, Symbol,
    Vec, U256,
};

#[contract]
pub struct LiquidityPoolXLM;

// pub const XLM_CONTRACT_ID: [u8; 32] = [0; 32];
const TLL_LEDGERS_YEAR: u32 = 6307200;
const TLL_LEDGERS_10YEAR: u32 = 6307200 * 10;
const _TLL_LEDGERS_MONTH: u32 = 518400;

const C1: u128 = 100000000000000000;
const C2: u128 = 3 * 100000000000000000;
const C3: u128 = 35 * 100000000000000000;
const SECS_PER_YEAR: u128 = 31556952 * 1000000000000000000;

#[contractimpl]
impl LiquidityPoolXLM {
    pub fn set_admin(env: Env, admin: Address) -> Result<String, LendingError> {
        let key = DataKey::Admin;
        if !env.storage().persistent().has(&key) {
            env.storage().persistent().set(&DataKey::Admin, &admin);
            Self::extend_ttl_datakey(&env, key);
        } else {
            panic!("Admin key has already been set");
        }
        Ok(String::from_str(&env, "Adminkey set successfully"))
    }

    pub fn get_admin(env: Env) -> Result<String, LendingError> {
        let key = DataKey::Admin;
        let admin_address: Address = env
            .storage()
            .persistent()
            .get(&key)
            .unwrap_or_else(|| panic!("Admin key has not been set"));
        Ok(admin_address.to_string())
    }

    pub fn initialize_pool_xlm(
        env: Env,
        native_token_address: Address,
        vxlm_token_address: Address,
        registry_contract: Address,
        treasury_address: Address,
        account_manager: Address,
        rate_model: Address,
    ) -> Result<String, LendingError> {
        let admin: Address = env
            .storage()
            .persistent()
            .get(&DataKey::Admin)
            .expect("Admin not set");

        admin.require_auth();
        let xlm_symbol = Symbol::new(&env, "XLM");
        let vxlm_symbol = Symbol::new(&env, "vXLM");

        env.storage()
            .persistent()
            .set(&ContractDetails::RegistryContract, &registry_contract);
        Self::extend_ttl_contractdatakey(&env, ContractDetails::RegistryContract);

        env.storage()
            .persistent()
            .set(&ContractDetails::AccountManager, &account_manager);
        Self::extend_ttl_contractdatakey(&env, ContractDetails::AccountManager);

        env.storage()
            .persistent()
            .set(&ContractDetails::RateModel, &rate_model);
        Self::extend_ttl_contractdatakey(&env, ContractDetails::RateModel);

        env.storage()
            .persistent()
            .set(&ContractDetails::Treasury, &treasury_address);
        Self::extend_ttl_contractdatakey(&env, ContractDetails::Treasury);

        env.storage().persistent().set(
            &TokenDataKey::VTokenClientAddress(vxlm_symbol.clone()),
            &vxlm_token_address,
        );
        Self::extend_ttl_tokendatakey(&env, TokenDataKey::VTokenClientAddress(vxlm_symbol.clone()));

        env.storage()
            .persistent()
            .set(&TokenDataKey::NativeXLMClientAddress, &native_token_address);
        Self::extend_ttl_tokendatakey(&env, TokenDataKey::NativeXLMClientAddress);

        // env.storage().persistent().set(
        //     &PoolDataKey::PoolAddress(xlm_symbol.clone()),
        //     &xlm_pool_address,
        // );
        // Self::extend_ttl_pooldatakey(&env, PoolDataKey::PoolAddress(xlm_symbol.clone()));

        env.storage()
            .persistent()
            .set(&TokenDataKey::TokenIssuerAddress, &admin.clone());
        Self::extend_ttl_tokendatakey(&env, TokenDataKey::TokenIssuerAddress);

        env.storage().persistent().set(
            &PoolDataKey::Pool(xlm_symbol.clone()),
            &U256::from_u128(&env, 0),
        ); // Store the XLM this contract handles
        Self::extend_ttl_pooldatakey(&env, PoolDataKey::Pool(xlm_symbol.clone()));
        Ok(String::from_str(&env, "XLM pool initialised"))
    }

    pub fn deposit_xlm(env: Env, lender: Address, amount: U256) {
        lender.require_auth();
        if amount <= U256::from_u128(&env, 0) {
            panic!("Deposit amount must be positive");
        }
        // Check if pool is initialised
        Self::is_xlm_pool_initialised(&env, Symbol::new(&env, "XLM"));

        let amount_u128: u128 = amount
            .to_u128()
            .unwrap_or_else(|| panic_with_error!(&env, LendingError::IntegerConversionError));

        // Getting the amount of tokens to be minted for Asset deposited
        let vtokens_to_be_minted = Self::convert_xlm_to_vtoken(&env, amount.clone());

        let native_token_address: Address = Self::get_native_xlm_client_address(&env);
        let xlm_token = token::Client::new(&env, &native_token_address);

        let user_balance = xlm_token.balance(&lender) as u128;

        if user_balance < amount_u128 {
            panic_with_error!(&env, LendingError::InsufficientBalance);
        }

        let xlm_pool_address: Address = env
            .storage()
            .persistent()
            .get(&PoolDataKey::PoolAddress(Symbol::new(&env, "XLM")))
            .unwrap_or_else(|| panic!("Failed to fetch XLM pool address"));

        // Transfer XLM from user to this contract
        xlm_token.transfer(
            &lender,                         // from
            &env.current_contract_address(), // to
            &(amount_u128 as i128),
        );

        // Update lender list
        Self::add_lender_to_list_xlm(&env, &lender);

        let key = PoolDataKey::LenderBalance(lender.clone(), Symbol::new(&env, "XLM"));

        // Adding amount to Lenders balance, first check current balance, if no balance start with 0
        let current_balance: U256 = env
            .storage()
            .persistent()
            .get(&key)
            .unwrap_or(U256::from_u128(&env, 0)); // Use U256::from_u128 or U256::zero to initialize U256

        let new_balance = current_balance.add(&amount);

        env.storage().persistent().set(&key, &new_balance);
        Self::extend_ttl_pooldatakey(&env, key);

        // Adding same amount to Total Pool balance
        let current_pool: U256 = env
            .storage()
            .persistent()
            .get(&PoolDataKey::Pool(Symbol::new(&env, "XLM")))
            .unwrap_or(U256::from_u128(&env, 0));

        let new_pool = current_pool.add(&amount);

        env.storage()
            .persistent()
            .set(&PoolDataKey::Pool(Symbol::new(&env, "XLM")), &(new_pool));
        Self::extend_ttl_pooldatakey(&env, PoolDataKey::Pool(Symbol::new(&env, "XLM")));

        let token_value: U256 = env
            .storage()
            .persistent()
            .get(&TokenDataKey::VTokenValue(Symbol::new(&env, "vXLM")))
            .unwrap();

        // Making sure token_value is not zero before dividing
        if token_value == U256::from_u128(&env, 0) {
            panic!("InvalidVTokenValue");
            // panic_with_error!(&env, LendingTokenError::InvalidVTokenValue);
        }

        // let vtokens_to_be_minted = amount.div(&token_value);

        // Now Mint the vXLM tokens that were created for the lender
        Self::mint_vxlm_tokens(&env, lender.clone(), vtokens_to_be_minted, token_value);

        env.events().publish(
            (Symbol::new(&env, "deposit_event"), lender.clone()),
            LendingDepositEvent {
                lender: lender.clone(),
                amount: amount,
                timestamp: env.ledger().timestamp(),
                asset_symbol: Symbol::new(&env, "XLM"),
            },
        );
    }

    pub fn redeem_vxlm(env: &Env, lender: Address, tokens_to_redeem: U256) {
        lender.require_auth();
        // Check if pool is initialised
        Self::is_xlm_pool_initialised(&env, Symbol::new(&env, "XLM"));

        let key_k = TokenDataKey::VTokenBalance(lender.clone(), Symbol::new(&env, "vXLM"));
        let vxlm_balance = env
            .storage()
            .persistent()
            .get(&key_k)
            .unwrap_or_else(|| U256::from_u32(&env, 0));

        if tokens_to_redeem > vxlm_balance {
            panic!("Insufficient Token Balance to redeem");
        }

        let xlm_value = Self::convert_vtoken_to_asset(env, tokens_to_redeem.clone());

        let key = PoolDataKey::LenderBalance(lender.clone(), Symbol::new(&env, "XLM"));

        // Check if lender has registered
        if !env.storage().persistent().has(&key) {
            panic!("Lender not registered");
        }

        // Check if lender has enough balance to deduct
        let current_balance: U256 = env.storage().persistent().get(&key).unwrap();

        // // Getting amount of vXLM tokens to burn from the lender to get the amount of XLM he withdraws
        // let vtokens_to_be_burnt = Self::convert_xlm_to_vtoken(&env, amount.clone());

        let native_token_address: Address = Self::get_native_xlm_client_address(&env);
        let xlm_token = token::Client::new(&env, &native_token_address);

        let amount_u128: u128 = xlm_value
            .to_u128()
            .unwrap_or_else(|| panic_with_error!(&env, LendingError::IntegerConversionError));

        xlm_token.transfer(
            &env.current_contract_address(), // from
            &lender,                         // to
            &(amount_u128 as i128),
        );

        // First deduct amount from Lenders balance
        let new_balance = current_balance.sub(&xlm_value);
        env.storage().persistent().set(&key, &new_balance);
        Self::extend_ttl_pooldatakey(&env, key);

        let pool_key = PoolDataKey::Pool(Symbol::new(&env, "XLM"));
        // Deduct same amount from total pool balance
        let current_pool_balance: U256 = env
            .storage()
            .persistent()
            .get(&pool_key)
            .unwrap_or_else(|| panic_with_error!(&env, LendingError::PoolNotInitialized));
        if current_pool_balance < xlm_value {
            panic_with_error!(&env, LendingError::InsufficientPoolBalance);
        }

        env.storage()
            .persistent()
            .set(&pool_key, &(current_pool_balance.sub(&xlm_value)));
        Self::extend_ttl_pooldatakey(&env, pool_key);

        // Now burn the vXLM tokens that were created for the lender
        // Get token value per unit vxlm
        // When lender wants to withdraw amount of xlm, we need to calculate how many vxlm tokens to burn
        // This is done by dividing the amount of xlm by the token value per unit vxlm
        // token_value is latest value of each vXLM
        let token_value: U256 = env
            .storage()
            .persistent()
            .get(&TokenDataKey::VTokenValue(Symbol::new(&env, "vXLM")))
            .unwrap();

        // Making sure token_value is not zero before dividing
        if token_value == U256::from_u128(&env, 0) {
            panic_with_error!(&env, LendingTokenError::InvalidVTokenValue);
        }

        Self::burn_vxlm_tokens(&env, lender.clone(), tokens_to_redeem.clone(), token_value);

        // emit event after withdraw
        env.events().publish(
            (Symbol::new(&env, "withdraw_event"), lender.clone()),
            LendingWithdrawEvent {
                lender: lender,
                vtoken_amount: tokens_to_redeem,
                timestamp: env.ledger().timestamp(),
                asset_symbol: Symbol::new(&env, "XLM"),
            },
        );
    }

    pub fn lend_to(
        env: &Env,
        account_manager: Address,
        trader: Address,
        amount: U256,
    ) -> Result<bool, LendingError> {
        // account_manager.require_auth();
        let borrow_shares = Self::convert_asset_borrow_shares(env, amount.clone());
        let mut is_first_borrow: bool = false;

        let key_a = PoolDataKey::UserBorrowShares(trader.clone());
        let key_b = PoolDataKey::TotalBorrowShares;
        let key_c = PoolDataKey::Borrows;
        let user_borrow_shares: U256 = env.storage().persistent().get(&key_a).unwrap();
        let total_borrow_shares: U256 = env.storage().persistent().get(&key_b).unwrap();
        let borrows: U256 = env.storage().persistent().get(&key_c).unwrap();

        if user_borrow_shares == U256::from_u32(&env, 0) {
            is_first_borrow = true;
        }

        let res1 = user_borrow_shares.add(&borrow_shares.clone());
        let res2 = total_borrow_shares.add(&borrow_shares.clone());
        let res3 = borrows.add(&amount.clone());

        env.storage().persistent().set(&key_a, &res1);
        env.storage().persistent().set(&key_b, &res2);
        env.storage().persistent().set(&key_c, &res3);
        Self::extend_ttl_pooldatakey(env, key_a);
        Self::extend_ttl_pooldatakey(env, key_b);
        Self::extend_ttl_pooldatakey(env, key_c);

        // Now transfer amount to trader address
        let native_token_address: Address = Self::get_native_xlm_client_address(&env);
        let xlm_token = token::Client::new(&env, &native_token_address);
        let amount_u128: u128 = amount
            .to_u128()
            .unwrap_or_else(|| panic_with_error!(&env, LendingError::IntegerConversionError));
        xlm_token.transfer(
            &env.current_contract_address(), // from
            &trader,                         // to
            &(amount_u128 as i128),
        );

        Ok(is_first_borrow)
    }

    pub fn collect_from(
        env: &Env,
        account_manager: Address,
        amount: U256,
        trader: Address,
    ) -> Result<bool, LendingError> {
        // account_manager.require_auth();
        let borrow_shares = Self::convert_asset_borrow_shares(env, amount.clone());
        if borrow_shares == U256::from_u32(&env, 0) {
            panic!("Zero borrow shares");
        }

        let user_borrow_shares: U256 = Self::get_user_borrow_shares(env, trader.clone());
        let total_borrow_shares: U256 = Self::get_total_borrow_shares(env);
        let key_c = PoolDataKey::Borrows;
        let borrows: U256 = env.storage().persistent().get(&key_c).unwrap();

        let res1 = user_borrow_shares.sub(&borrow_shares);
        let res2 = total_borrow_shares.sub(&borrow_shares);
        let res3 = borrows.sub(&amount);
        Self::set_user_borrow_shares(env, trader.clone(), res1.clone());
        Self::set_total_borrow_shares(env, res2);
        env.storage().persistent().set(&key_c, &res3);
        return Ok(res1 == U256::from_u32(&env, 0));
    }

    fn mint_vxlm_tokens(env: &Env, lender: Address, tokens_to_mint: U256, token_value: U256) {
        let key = TokenDataKey::VTokenBalance(lender.clone(), Symbol::new(&env, "vXLM"));

        // Check if user has balance initialised, else initialise key for user
        if !env.storage().persistent().has(&key) {
            env.storage()
                .persistent()
                .set(&key, &U256::from_u128(&env, 0));
            Self::extend_ttl_tokendatakey(&env, key.clone());
        }

        let tokens_to_mint_u128: u128 = tokens_to_mint
            .to_u128()
            .unwrap_or_else(|| panic_with_error!(&env, LendingError::IntegerConversionError));
        let vxlm_symbol = Symbol::new(&env, "vXLM");

        let token_address: Address = env
            .storage()
            .persistent()
            .get(&TokenDataKey::VTokenClientAddress(vxlm_symbol))
            .unwrap();

        let token_sac = token::StellarAssetClient::new(&env, &token_address);

        // mint tokens to his address.
        token_sac.mint(&lender, &(tokens_to_mint_u128 as i128)); // Mint tokens to recipient

        let current_vxlm_balance: U256 = env.storage().persistent().get(&key).unwrap();
        let new_vxlm_balance = current_vxlm_balance.add(&tokens_to_mint);
        env.storage().persistent().set(&key, &new_vxlm_balance);
        Self::extend_ttl_tokendatakey(&env, key.clone());

        // Update total token balance available right now
        let current_total_token_balance = Self::get_current_total_vxlm_balance(env);
        let new_total_token_balance = current_total_token_balance.add(&tokens_to_mint);
        let key_x = TokenDataKey::CurrentVTokenBalance(Symbol::new(&env, "vXLM"));
        env.storage()
            .persistent()
            .set(&key_x, &new_total_token_balance);
        Self::extend_ttl_tokendatakey(&env, key_x);

        let total_minted = Self::get_total_vxlm_minted(env);
        let new_total_minted = total_minted.add(&tokens_to_mint);
        let key_y = TokenDataKey::TotalTokensMinted(Symbol::new(&env, "vXLM"));
        env.storage().persistent().set(&key_y, &new_total_minted);
        Self::extend_ttl_tokendatakey(&env, key_y);

        env.events().publish(
            (Symbol::new(&env, "mint_event"), lender.clone()),
            LendingTokenMintEvent {
                lender: lender.clone(),
                token_amount: tokens_to_mint,
                timestamp: env.ledger().timestamp(),
                token_symbol: Symbol::new(&env, "vXLM"),
                token_value: token_value,
            },
        );
    }

    fn burn_vxlm_tokens(env: &Env, lender: Address, tokens_to_burn: U256, token_value: U256) {
        let key = TokenDataKey::VTokenBalance(lender.clone(), Symbol::new(&env, "vXLM"));
        if !env.storage().persistent().has(&key) {
            panic_with_error!(&env, LendingTokenError::TokenBalanceNotInitialised);
        }

        let current_vxlm_balance: U256 = env.storage().persistent().get(&key).unwrap();
        // Check if user has enough tokens to burn
        if current_vxlm_balance < tokens_to_burn {
            panic_with_error!(&env, LendingTokenError::InsufficientTokenBalance);
        }

        let new_vxlm_balance = current_vxlm_balance.sub(&tokens_to_burn);
        env.storage().persistent().set(&key, &new_vxlm_balance);
        Self::extend_ttl_tokendatakey(&env, key);

        let tokens_to_burn_u128: u128 = tokens_to_burn
            .to_u128()
            .unwrap_or_else(|| panic_with_error!(&env, LendingError::IntegerConversionError));
        let vxlm_symbol = Symbol::new(&env, "vXLM");

        let token_address: Address = env
            .storage()
            .persistent()
            .get(&TokenDataKey::VTokenClientAddress(vxlm_symbol))
            .unwrap();

        let token_sac = token::TokenClient::new(&env, &token_address);

        // burn tokens from his address.
        token_sac.burn(&lender, &(tokens_to_burn_u128 as i128));

        let current_total_token_balance = Self::get_current_total_vxlm_balance(env);
        let new_total_token_balance = current_total_token_balance.sub(&tokens_to_burn);
        env.storage().persistent().set(
            &TokenDataKey::CurrentVTokenBalance(Symbol::new(&env, "vXLM")),
            &new_total_token_balance,
        );
        Self::extend_ttl_tokendatakey(
            &env,
            TokenDataKey::CurrentVTokenBalance(Symbol::new(&env, "vXLM")),
        );

        let total_burnt = Self::get_total_vxlm_burnt(env);
        let new_total_burnt = total_burnt.add(&tokens_to_burn);
        let key_a = TokenDataKey::TotalTokensBurnt(Symbol::new(&env, "vXLM"));
        env.storage().persistent().set(&key_a, &new_total_burnt);
        Self::extend_ttl_tokendatakey(&env, key_a);

        env.events().publish(
            (Symbol::new(&env, "burn_event"), lender.clone()),
            LendingTokenBurnEvent {
                lender: lender.clone(),
                token_amount: tokens_to_burn,
                timestamp: env.ledger().timestamp(),
                token_symbol: Symbol::new(&env, "vXLM"),
                token_value,
            },
        );
    }

    pub fn get_xlm_pool_balance(env: &Env) -> U256 {
        Self::is_xlm_pool_initialised(&env, Symbol::new(&env, "XLM"));

        env.storage()
            .persistent()
            .get(&PoolDataKey::Pool(Symbol::new(&env, "XLM")))
            .unwrap_or(U256::from_u128(&env, 0))
    }

    pub fn convert_asset_borrow_shares(env: &Env, amount: U256) -> U256 {
        let key_b = PoolDataKey::TotalBorrowShares;
        let total_borrow_shares: U256 = env.storage().persistent().get(&key_b).unwrap();

        if total_borrow_shares == U256::from_u32(&env, 0) {
            return amount;
        } else {
            let res = amount.mul(&total_borrow_shares);
            let result = res.div(&Self::get_borrows(&env));
            return result;
        }
    }

    pub fn convert_borrow_shares_asset(env: &Env, debt: U256) -> U256 {
        let key_b = PoolDataKey::TotalBorrowShares;
        let total_borrow_shares: U256 = env.storage().persistent().get(&key_b).unwrap();
        if total_borrow_shares == U256::from_u32(&env, 0) {
            return debt;
        } else {
            let res = debt.mul(&Self::get_borrows(&env));
            let result = res.div(&total_borrow_shares);
            return result;
        }
    }

    pub fn update_state(env: &Env) {
        let lastupdatetime = Self::get_last_updated_time(&env);
        if lastupdatetime == env.ledger().timestamp() {
            return;
        }
        let key_c = PoolDataKey::Borrows;
        let borrows: U256 = env.storage().persistent().get(&key_c).unwrap();
        let rate_factor = Self::get_rate_factor(&env).unwrap();
        let interest_accrued = borrows.mul(&rate_factor);
        let res = borrows.add(&interest_accrued);
        env.storage().persistent().set(&key_c, &res);
        env.storage()
            .persistent()
            .set(&PoolDataKey::LastUpdatedTime, &env.ledger().timestamp());
    }

    pub fn before_deposit(env: &Env) {
        Self::update_state(env);
    }
    pub fn before_withdraw(env: &Env) {
        Self::update_state(env);
    }

    pub fn get_user_borrow_shares(env: &Env, trader: Address) -> U256 {
        let key_a = PoolDataKey::UserBorrowShares(trader.clone());
        let user_borrow_shares: U256 = env.storage().persistent().get(&key_a).unwrap();
        return user_borrow_shares;
    }

    pub fn set_user_borrow_shares(env: &Env, trader: Address, res: U256) {
        let key_a = PoolDataKey::UserBorrowShares(trader.clone());
        env.storage().persistent().set(&key_a, &res);
        Self::extend_ttl_pooldatakey(env, key_a);
    }
    pub fn get_borrow_balance(env: &Env, trader: Address) -> U256 {
        let key_a = PoolDataKey::UserBorrowShares(trader.clone());
        let user_borrow_shares: U256 = env.storage().persistent().get(&key_a).unwrap();
        let res = Self::convert_borrow_shares_asset(env, user_borrow_shares);
        res
    }

    pub fn get_total_borrow_shares(env: &Env) -> U256 {
        let key_b = PoolDataKey::TotalBorrowShares;
        let total_borrow_shares: U256 = env.storage().persistent().get(&key_b).unwrap();
        return total_borrow_shares;
    }

    pub fn set_total_borrow_shares(env: &Env, res: U256) {
        let key_b = PoolDataKey::TotalBorrowShares;
        env.storage().persistent().set(&key_b, &res);
        Self::extend_ttl_pooldatakey(env, key_b);
    }

    pub fn total_assets(env: &Env) -> U256 {
        let token = Symbol::new(&env, "XLM");
        let assets = Self::get_total_liquidity_in_pool(&env, token.clone());
        let borrows = Self::get_borrows(env);
        let total_assets = assets.add(&borrows);
        total_assets
    }

    pub fn get_borrows(env: &Env) -> U256 {
        let key_c = PoolDataKey::Borrows;

        let borrows: U256 = env.storage().persistent().get(&key_c).unwrap();
        let res = borrows.mul(&Self::get_rate_factor(&env).unwrap());
        let result = borrows.add(&res);
        result
    }

    pub fn get_rate_factor(env: &Env) -> Result<U256, InterestRateError> {
        let lastupdatetime = Self::get_last_updated_time(&env);
        let blocktimestamp = env.ledger().timestamp();
        if lastupdatetime == env.ledger().timestamp() {
            return Ok(U256::from_u32(&env, 0));
        }
        let token = Symbol::new(&env, "XLM");

        let key_c = PoolDataKey::Borrows;

        let borrows: U256 = env.storage().persistent().get(&key_c).unwrap();
        let liquidity = Self::get_total_liquidity_in_pool(&env, token.clone());

        let res = U256::from_u128(&env, (blocktimestamp - lastupdatetime) as u128)
            .mul(&(Self::get_borrow_rate_per_sec(&env, liquidity, borrows).unwrap()));

        Ok(res)
    }

    pub fn get_total_liquidity_in_pool(env: &Env, token_symbol: Symbol) -> U256 {
        env.storage()
            .persistent()
            .get(&PoolDataKey::Pool(token_symbol))
            .unwrap_or(U256::from_u128(&env, 0))
    }

    pub fn get_last_updated_time(env: &Env) -> u64 {
        env.storage()
            .persistent()
            .get(&PoolDataKey::LastUpdatedTime)
            .unwrap_or_else(|| env.ledger().timestamp())
    }

    pub fn get_current_total_vxlm_balance(env: &Env) -> U256 {
        env.storage()
            .persistent()
            .get(&TokenDataKey::CurrentVTokenBalance(Symbol::new(
                &env, "vXLM",
            )))
            .unwrap_or_else(|| U256::from_u128(&env, 0))
    }

    pub fn get_total_vxlm_minted(env: &Env) -> U256 {
        env.storage()
            .persistent()
            .get(&TokenDataKey::TotalTokensMinted(Symbol::new(&env, "vXLM")))
            .unwrap_or_else(|| U256::from_u128(&env, 0))
    }

    pub fn get_total_vxlm_burnt(env: &Env) -> U256 {
        env.storage()
            .persistent()
            .get(&TokenDataKey::TotalTokensBurnt(Symbol::new(&env, "vXLM")))
            .unwrap_or_else(|| U256::from_u128(&env, 0))
    }

    // Helper function to add lender to list
    fn add_lender_to_list_xlm(env: &Env, lender: &Address) {
        let mut lenders: Vec<Address> = env
            .storage()
            .persistent()
            .get(&PoolDataKey::Lenders(Symbol::new(&env, "XLM")))
            .unwrap_or_else(|| Vec::new(&env));

        if !lenders.contains(lender) {
            lenders.push_back(lender.clone());
            let key_b = PoolDataKey::Lenders(Symbol::new(&env, "XLM"));
            env.storage().persistent().set(&key_b, &lenders);
            Self::extend_ttl_pooldatakey(&env, key_b);
        }
    }

    // Function to get all lenders
    pub fn get_lenders_xlm(env: Env) -> Vec<Address> {
        let list_address: Vec<Address> = env
            .storage()
            .persistent()
            .get(&PoolDataKey::Lenders(Symbol::new(&env, "XLM")))
            .unwrap_or_else(|| Vec::new(&env));
        list_address
    }

    pub fn is_xlm_pool_initialised(env: &Env, asset: Symbol) -> bool {
        if !env.storage().persistent().has(&PoolDataKey::Pool(asset)) {
            // panic!("Pool not initialised");
            panic_with_error!(&env, LendingError::PoolNotInitialized);
        }
        true
    }

    pub fn get_xlm_pool_address(env: &Env) -> Address {
        env.storage()
            .persistent()
            .get(&PoolDataKey::PoolAddress(Symbol::new(&env, "XLM").clone()))
            .unwrap_or_else(|| panic!("XLM pool address not set"))
    }

    pub fn get_native_xlm_client_address(env: &Env) -> Address {
        env.storage()
            .persistent()
            .get(&TokenDataKey::NativeXLMClientAddress)
            .unwrap_or_else(|| panic!("Native XLM client address not set"))
    }

    // Converts XLM to vXLM
    pub fn convert_xlm_to_vtoken(env: &Env, amount: U256) -> U256 {
        let pool_balance = Self::get_xlm_pool_balance(env);
        let minted = Self::get_total_vxlm_minted(env);

        if pool_balance == U256::from_u128(&env, 0) || minted == U256::from_u128(&env, 0) {
            amount
        } else {
            let supply = Self::get_current_total_vxlm_balance(env);
            let total_liquidity_pool =
                Self::get_total_liquidity_in_pool(env, Symbol::new(&env, "XLM"));

            let res = amount.mul(&supply);
            let resx = res.div(&total_liquidity_pool);

            let vtoken_value = amount.div(&resx);
            env.storage().persistent().set(
                &TokenDataKey::VTokenValue(Symbol::new(&env, "vXLM")),
                &vtoken_value,
            );
            Self::extend_ttl_tokendatakey(
                &env,
                TokenDataKey::VTokenValue(Symbol::new(&env, "vXLM")),
            );
            resx
        }
    }

    //  Converting vXLM to XLM
    pub fn convert_vtoken_to_asset(env: &Env, vtokens_to_be_burnt: U256) -> U256 {
        let pool_balance = Self::get_xlm_pool_balance(env);
        let v_token_supply = Self::get_current_total_vxlm_balance(env);
        let res = vtokens_to_be_burnt.mul(&pool_balance);
        let resx = res.div(&v_token_supply);

        let vtoken_value = resx.div(&vtokens_to_be_burnt);
        env.storage().persistent().set(
            &TokenDataKey::VTokenValue(Symbol::new(&env, "vXLM")),
            &vtoken_value,
        );
        Self::extend_ttl_tokendatakey(&env, TokenDataKey::VTokenValue(Symbol::new(&env, "vXLM")));

        resx
    }

    pub fn get_borrow_rate_per_sec(
        env: &Env,
        liquidity: U256,
        borrows: U256,
    ) -> Result<U256, InterestRateError> {
        let util = Self::get_utilisation_ratio(env, liquidity, borrows)
            .expect("Panicked to get utilization ratio");
        let c1_u256 = U256::from_u128(&env, C1);
        let c2_u256 = U256::from_u128(&env, C2);
        let c3_u256 = U256::from_u128(&env, C3);
        let secs_per_year = U256::from_u128(&env, SECS_PER_YEAR);

        let x = (util.pow(32)).mul(&c1_u256);
        let y = (util.pow(64)).mul(&c2_u256);
        let rhs = util.mul(&c1_u256).add(&(x.add(&y)));
        let result = c3_u256.mul(&rhs);
        let res = result.div(&secs_per_year);

        Ok(res)
    }
    pub fn get_utilisation_ratio(
        env: &Env,
        liquidity: U256,
        borrows: U256,
    ) -> Result<U256, InterestRateError> {
        let total_assets = liquidity.add(&borrows);

        if total_assets == U256::from_u128(&env, 0) {
            Ok(U256::from_u128(&env, 0))
        } else {
            Ok(borrows.div(&total_assets))
        }
    }

    fn extend_ttl_datakey(env: &Env, key: DataKey) {
        env.storage()
            .persistent()
            .extend_ttl(&key, TLL_LEDGERS_YEAR, TLL_LEDGERS_10YEAR);
    }

    fn extend_ttl_pooldatakey(env: &Env, key: PoolDataKey) {
        env.storage()
            .persistent()
            .extend_ttl(&key, TLL_LEDGERS_YEAR, TLL_LEDGERS_10YEAR);
    }

    fn extend_ttl_tokendatakey(env: &Env, key: TokenDataKey) {
        env.storage()
            .persistent()
            .extend_ttl(&key, TLL_LEDGERS_YEAR, TLL_LEDGERS_10YEAR);
    }

    fn extend_ttl_contractdatakey(env: &Env, key: ContractDetails) {
        env.storage()
            .persistent()
            .extend_ttl(&key, TLL_LEDGERS_YEAR, TLL_LEDGERS_10YEAR);
    }
}
